Nils BARRELLON - 21601602

1) "J'ai" réalisé la fonction get_local_ip() à l'aide du LLM Le Chat de Mistral AI.
En effet, pour essayer mes scripts sur 2 machines différentes connectées sur mon réseau personnel, 
j'avais besoin de l'IP réseau de mon serveur que j'obtenais avec la commande shell ip a 
mais je souhaitais que cette dernière s'affiche au lancement de mon serveur.

Mon prompt : "Je voudrais que le serveur (codé dans le fichier python que je te fournis) affiche l'adresse IP 
sur laquelle on peut se connecter à lui."

Il m'a fallu quelques aller-retours pour obtenir ce que je souhaitais.

2) J'ai aussi utilisé l'IA pour le formatage d'une réponse HTTP et notamment les champs d'en-tête.

